# Pydantic schemas for API contracts
