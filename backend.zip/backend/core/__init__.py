# Core infrastructure and configuration
